-------------------------------------------------------------------------
.jar file - CommonFunLib Source Code
.war file - CommonFunLib API Package for selfhosting 
-------------------------------------------------------------------------